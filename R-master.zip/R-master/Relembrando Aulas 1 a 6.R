ls()
data <- "07/04/2019"
v <- c"Frodo","Lucy","Artur"
Kender <- "Kenmedera"
Atributos <- 10
Kender
ls()
Arquivos <- dir("d:/R Language")
dir.exists("d:/Kotlin")
Arquivos
aa <- 2
bb <- 5
cc <- 3
x <- 2
equacao <- (aa*x**x)+(bb*x)+cc
equacao
ls()
x
rm(x)
equacao<- (aa*x**x)+(bb*x)+cc
equacao
rm(list = ls())
ls()
