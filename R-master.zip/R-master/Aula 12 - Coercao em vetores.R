#Coerção de valores em vetores
#Vetores somente podem ter um tipo de dado
numeros <- c(1:5)
class(numeros)
numeros[5] <- 5.5
numeros
class(numeros)
numeros<- c(numeros, 4L)
numeros <- c(numeros, "Artur")
numeros
numeros[7] <- 7
class(numeros)

numeros <- c(numeros, FALSE)
numeros
