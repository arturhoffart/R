#Operações matemáticas em vetores
numeros <- c(1:10)
numeros <- numeros *10
numeros <- numeros[c(TRUE, FALSE)] / 10
numeros
ls()
x
numeros * x
multi <- c(2:6)
numeros * multi
