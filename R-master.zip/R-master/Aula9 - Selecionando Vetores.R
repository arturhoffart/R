#Aula 9 - selecionando valores de um vetor

#Vetor teste
numeros <- c(1:10)
numeros


#selecionar pelo index do 1 pra frente
numeros[2]
names(numeros) <- c("um","dois","tres","quatro","cinco","seis","sete","oito","nove","dez")

numeros["dez"]
x <- 6
numeros[x]

#Vetor de lógicos
numeros[c(TRUE,FALSE)]
