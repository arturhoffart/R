#Variáveis
#Atribuindo valores
variavel <- 10
variavel
variavel <- "Artur"
variavel

#resultado de um calculo
variavel <- 20 ^20
variavel