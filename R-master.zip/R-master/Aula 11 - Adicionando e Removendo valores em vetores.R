#Adicionando e removendo valores no vetor
vitorias <- c(1:5)
names(vitorias) <- c("v1", "v2", "v3", "v4", "v5")
vitorias

#Adicionar valores por index
vitorias[6] <- 6

#Adicionar valores por comprimento
vitorias[length(vitorias)+1] <- 7

#Adicionar valores com outro vetor
vitorias <- c(vitorias, 8)

#Remover valores via index
vitorias[-5]

vitorias <- vitorias[-3]
vitorias <- vitorias[-c(1:3)]
vitorias
