#Tipos básicos de dados
#numeros
#inteiro - integer
4
class(4L)

#ponto flutuante
#Numeric
4.3
Class(65.999)

#Caractere
#Character
"R"
class("R")

#Lógico TRUE ou FALSE t / f



#Complex - aula específica
