#nomeando vetores
vitorias <- c(1,2,3,4,5,6,7)
diasSemana<- c("Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sabado")
vitorias 
diasSemana
names(vitorias) <- diasSemana
vitorias

atributos <- c(10, 18, 14, 15, 11, 13)
atriNomes <- c("Força","Destreza","Constituição","Inteligencia","Sabedoria","Carisma")
names(atributos) <- atriNomes
kenderModificador <- c(0,2,0,0,0,1)
atributos <- atributos+kenderModificador
atributos[3]
atributos["Carisma"]
