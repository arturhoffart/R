#Download R https://cran.r-project.org/
#Download RStudio https://www.rstudio.com/products/rstudio/download/
#Operações básicas com R
#Adição
1 + 3

#Subtração
5 - 2

#Multiplicação
3 * 8

#Divisão
8 / 3

#Exponenciação
5 ^ 5

#Resto da Divisão
5 %% 2

#Ordem de Parenteses
2 * (2 + 4)
2* 2 + 4