#Tipos de dados
ls()
varI <- 5
is.integer(varI)
class(varI)
is.numeric(varI)


#Funcao is.[tipo de dado](variavel) retorna TRUE ou FALSE 
is.numeric(varI)
is.logical(varI)
is.integer(varI)
is.finite(varI)
is.infinite(varI)
is.character(varI)

#Acessar o help
?is.numeric
