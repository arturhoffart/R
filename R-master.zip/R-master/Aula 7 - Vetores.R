Aula 7 <- Vetores
c(1,2,3,4,5,6,7)
dias <- c(1,2,3,4,5,6,7)
dias
dias <- dias*2 # quando faz a multiplicação, ele multiplica todos os itens do vetor
dias
dias <- dias/2
dias
dias[2] #Em R o indice começa a contar a partir de 1
kender <- "Kenderkin"
is.vector(kender)
