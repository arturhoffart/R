#Criar variavel X
x <- 10

#Criando outra variavel
variavelWorkspace <- "Exemplo"

#Lista objetos do workspace
ls()

#Apagar objeto/variaveldo workspace
#rm(nome da varialvel)
rm(x)
ls()