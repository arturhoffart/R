#Aula 6 - Coerção de dados
varC <- "5"
varI <- 5
varN <- 4.5
varL <- T
